package com.tradingview.ci.kover

import org.gradle.api.provider.SetProperty
import org.gradle.api.provider.Property

interface KoverCoverageExtension {
    /** Модули, исключённые из coverage-отчёта */
    val excludedProjects: SetProperty<String>
    /** Префикс имени per-module тасок */
    val taskPrefix: Property<String>
    /** Префикс имени выходных файлов */
    val filePrefix: Property<String>
}

